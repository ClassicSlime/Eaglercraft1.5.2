# DoxrFood
### AKA LTVegan

> Hang the blocker and be unblocked.

1. Open `chrome://extensions/?id=adkcpkpghahmbopkjchobieckeoaoeem` (tab 1)
2. Open `chrome-extension://adkcpkpghahmbopkjchobieckeoaoeem/main.js` in a new tab (tab 2)
3. Go to tab 2 and do CTRL + A to copy all of the code on the site.
4. Drag the code to the top (this might do a google search with all of the code, that's fine). The chromebook will freeze for a little bit.
5. Right-click on tab 1 once you stop freezing and press the duplicate button.
6. Go to tab 2 and press the switch that says "Allow access to file URLs" (multiple times). One of the tabs that were duplicated will close, the other won't. DON'T CLOSE THE TAB THATS LOADING.
7. close the google tab, and close tab 1, and you should be unblocked!

If BOTH tabs of tab 2 (the original and duplicated) close, you did something wrong probably. Just try again or something.