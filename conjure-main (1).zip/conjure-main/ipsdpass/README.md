# IPSD-pass

This method uses a few links in IPSD's login screen to get to a different page unblocked.

> This bypass isn't very good since you can't use the arrow keys to go back and forward in pages, and some sites like Snapchat are still blocked, but that literally can't be bypassed.

Steps:

1. Log out
2. You should see "add a new user" on the bottom left, click on that.
3. In the login screen, press "Students: I Forgot My Password"
4. Click the blue "Click here" in the sentence that says `Click here for step-by-step instructions on using this form.`
5. You will find a sentence that says `Parent will visit ParentVUE at https://il-ipsd-psv.edupoint.com/PXP2_Login_Parent.aspx and log in with their ParentVUE username/password.`, click on the link (should bring you to StudentVUE)
6. Press "iPhone App"
7. Press on the search button (top right) and type in "DuckDuckGo," you'll find a thing that says "DuckDuckGo Private Browser," click on it.
8. You'll find a section that says "App Privacy," and in that you'll find a link that says "For more information, see the developer’s privacy policy." Click on it
9. You'll find an icon on the top left, click on it

Now you are done. Use DDG like how you use Google, but remember that once you click on a site you can't go back because this exploit is bad.