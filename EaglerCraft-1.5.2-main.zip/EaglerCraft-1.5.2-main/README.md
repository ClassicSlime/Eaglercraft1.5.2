# About EaglerCraft
EaglerCraft is a computer-dependant Minecraft player that runs 1.5.2 (Java)

EaglerCraft runs on any browser. Chrome, Firefox, Edge. Make sure to have at least a recent version.

EaglerCraft is CPU and RAM dependent. For a bare minumum result, please have 4GB RAM or more with a CPU with a 1.2GHZ (4 threads)

For a playable result, 6GB of RAM with a CPU of 1.7GHZ (4 threads)

EaglerCraft is not a cloud saved document, meaning transfering progress cross platforms (desktop to laptop). Saving via Drive/OneDrive doesn't cloud save progress as well. As said, EaglerCraft is computer-dependent, not cloud saved.

# Installing EaglerCraft (MacOS and Windows)

To install EaglerCraft, you need to just simply download the respitory as a .ZIP, then extract.

After extracting, you can them open the ***only*** HTML file and you can enjoy the game.

# Installing EaglerCraft (Simplified)

 Navigate yourself to the respitory and click **Offline_Download_Version.html**. Download the .html file and open it. You can name it to whatever you want,plus you can pin it in your shelf. After that, you can open it and start playing.
